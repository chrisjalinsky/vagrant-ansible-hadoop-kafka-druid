INSERT INTO BAR(id, name) VALUES (1, 'bar');
INSERT INTO BAR(id, name) VALUES (2, 'ばー');