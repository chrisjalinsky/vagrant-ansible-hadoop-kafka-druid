import java.io.*;
import org.springframework.boot.maven.*;

Verify.verifyZip(
	new File( basedir, "target/jar-0.0.1.BUILD-SNAPSHOT.jar" )
);

