import java.io.*;
import org.springframework.boot.maven.*;

Verify.verifyModule(new File( basedir, "target/module-0.0.1.BUILD-SNAPSHOT.jar" ));

